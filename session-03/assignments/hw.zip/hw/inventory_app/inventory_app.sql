CREATE DATABASE inventory_app;
use inventory_app;


